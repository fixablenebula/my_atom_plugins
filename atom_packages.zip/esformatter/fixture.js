function foo(){console.log('foo')}
function foo(){console.log('foo')}
