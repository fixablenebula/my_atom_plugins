## 0.8.0
* Add support for ES6

## 0.5.24
* Add support for multiply projects

## 0.4.13
* TypeView to display completions for fn-params

## 0.4.6
* Documentation now provides urls and origin
* Various improvements and bugfixing

## 0.4.4
* Improved decision if completion should be triggered

## 0.4.2
* Documentation is now being displayed via a panel
* Various bugfixing

## 0.4.0
* Implemented feature: Find references

## 0.3.8
* Package now works on Windows platform

## 0.0.1 - First Release
* First working example
