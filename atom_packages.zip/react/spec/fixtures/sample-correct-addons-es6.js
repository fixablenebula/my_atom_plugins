import React, { Component, PropTypes } from 'react/addons'; // import react
