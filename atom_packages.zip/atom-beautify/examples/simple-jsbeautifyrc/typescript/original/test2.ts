module XYZ {
  interface I {
   x: number,
   y,
   z
  }

    var zZz={
        a: 123,
        b: 456
    };

    enum En {
        AB,
        CD
    }

    var y = 3;

    switch(y {
        case X:
            console.log("x");
            break;
        default:
            console.log("y");
    }

    if (x === 3) {
        if (y === 4) {
            console.log("hey");
        }
        console.log("x");
        x = y.hey
              .b
              .c
              .d;


    export class X {
        private x : number;

        constructor() {
            console.log("hi");
        }

        public mem() {
            console.log("yes");
        }
    }

    function xyz() {
        function mem() {
            console.log("yes");
        }
    }
}