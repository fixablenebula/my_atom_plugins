<?php
public function FunctionName($value='')
{
  # code...
}

?>
